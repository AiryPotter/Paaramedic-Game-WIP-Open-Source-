# Paramedic Rush — Xogot prototype

A playable prototype of a paramedic game, written **only in GDScript** so it opens in
**Xogot** on iPad/iPhone and in desktop Godot 4.4+ (projects move between them both ways).
There are no imported assets, plugins, C# or native extensions. Everything is built from primitive shapes in code.

## The loop

1. A call comes in. Follow the **red beacon**.
2. Park, then press **USE** at the back doors. The stretcher rolls out with you already holding it.
3. **Toss the bags** at the stretcher. They stick to its **sticky pad** where they land.
4. **LOWER** the stretcher to LOW beside the patient, then **USE** to transfer them.
5. Push it to the back doors at LOW, **USE** to load, and drive.
6. Follow the **green beacon** to the hospital. Push up the ER ramp (heavy loads crawl uphill) and **USE** on the green pad.
7. Score = 500 + speed bonus + 100 per bag on the pad. The next call arrives 3 seconds later.

## Controls

| Action | Touch (iPad) | Keyboard | Controller |
|---|---|---|---|
| Move / push / drive | Left joystick (appears where you touch) | WASD / arrows | Left stick |
| Camera orbit | Drag on the right half | J / L | Right stick |
| USE (doors, transfer, load, hand-over) | USE | E / Enter | A |
| GRAB (bag or stretcher, let go) | GRAB | F | X |
| TOSS held bag (auto-aims at the pad) | TOSS | Q | RB |
| Handbrake slide | BRAKE | Space | LB / LT |
| Stretcher height | RAISE / LOWER | R / C | D-pad up / down |
| UNSTICK (drop all off the pad) | UNSTICK | G | B |
| Siren lights | SIREN | H | Y |

## Open it in Xogot

- **Option A:** copy the `paramedic_game` folder to iCloud Drive, then open it from Xogot's project list.
- **Option B:** if this repo is on GitHub, clone it to the iPad with Working Copy and open the folder in Xogot.

The project's main scene is `main.tscn`, so pressing Play is all you need.

## Files

| File | Role |
|---|---|
| `project.godot` | Mobile renderer, landscape, main scene |
| `main.tscn` | One node that runs `scripts/main.gd` |
| `scripts/main.gd` | Builds the town, hospital and ramps; runs calls, scoring, HUD and beacon |
| `scripts/ambulance.gd` | Arcade driving: drift, jumps, squash and stretch, bounces, doors, siren lights |
| `scripts/stretcher.gd` | Sim stretcher: 3 heights, mass, push power, slope gravity, top-heavy wobble |
| `scripts/sticky_pad.gd` | The sticky pad: catches bags, stacks them, holds the patient, UNSTICK |
| `scripts/prop.gd` | Bags and the patient (rigid bodies that can be frozen onto the pad) |
| `scripts/paramedic.gd` | The player: walking, carrying, tossing, pushing, driving, context hints |
| `scripts/follow_camera.gd` | Third-person camera with walk, push and drive presets; avoids walls |
| `scripts/touch_controls.gd` | Multi-touch joystick, buttons and camera drag |
| `scripts/input_setup.gd` | Registers all input actions in code |

## Tuning

Every feel value is an `@export` variable near the top of its script, with units in the comments.
The most useful knobs are listed in `RECOMMENDATIONS.md`.

## Tested

An automated play-through in Godot 4.4.1 checked every step of the loop: unload, push, raise, pick up, toss and stick, lower, transfer, stow, drive, handbrake, exit, unload at the ER, push up the ramp, hand-over, next call and UNSTICK. All 22 checks passed.
I also rendered screenshots to confirm the ambulance, stretcher, pad, bags and HUD draw correctly.
I have not run it on a real iPad. Check touch feel and frame rate there first.
