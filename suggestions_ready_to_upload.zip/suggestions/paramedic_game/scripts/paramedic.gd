extends CharacterBody3D
## The paramedic (player character). On foot: walk, pick up and toss bags,
## unload the stretcher. Pushing: tank-style stretcher control, height changes,
## patient transfer, loading into the ambulance and hand-over at the ER.
## Driving: steers the ambulance.

enum Mode { WALK, PUSH, DRIVE }

const LAYER_PLAYER := 1 << 2
const MASK_PLAYER := (1 << 0) | (1 << 1) | (1 << 3) | (1 << 4)
const HEIGHT_LOW := 0

@export var walk_speed: float = 4.8
@export var acceleration: float = 30.0
@export var reach: float = 1.9              # pick-up range for bags
@export var grab_reach: float = 1.6         # range to the stretcher handle
@export var throw_speed: float = 7.0
@export var throw_lift: float = 3.5
@export var auto_aim_range: float = 9.0
@export var auto_aim_angle: float = 60.0    # degrees either side of facing
@export var gravity: float = 9.8

var mode: int = Mode.WALK
var held_prop = null
var game        # main.gd
var ambulance   # ambulance.gd
var stretcher   # stretcher.gd
var cam         # follow_camera.gd
var hand: Node3D


func _ready() -> void:
	collision_layer = LAYER_PLAYER
	collision_mask = MASK_PLAYER
	floor_snap_length = 0.3
	_build()


func _physics_process(delta: float) -> void:
	if game == null or cam == null:
		return
	match mode:
		Mode.WALK:
			_process_walk(delta)
		Mode.PUSH:
			_process_push()
		Mode.DRIVE:
			_process_drive()
	game.set_hint(_context_hint())


# ---------------------------------------------------------------- modes

func _process_walk(delta: float) -> void:
	var input := Input.get_vector("move_left", "move_right", "move_up", "move_down")
	var dir := Vector3(input.x, 0.0, input.y).rotated(Vector3.UP, cam.yaw)
	velocity.x = move_toward(velocity.x, dir.x * walk_speed, acceleration * delta)
	velocity.z = move_toward(velocity.z, dir.z * walk_speed, acceleration * delta)
	if not is_on_floor():
		velocity.y -= gravity * delta
	move_and_slide()
	if dir.length() > 0.1:
		rotation.y = lerp_angle(rotation.y, atan2(-dir.x, -dir.z), 1.0 - exp(-12.0 * delta))
	if Input.is_action_just_pressed("interact"):
		_interact_on_foot()
	elif Input.is_action_just_pressed("grab"):
		_grab_on_foot()
	elif Input.is_action_just_pressed("throw"):
		_throw()
	_stretcher_buttons(_near_stretcher())


func _process_push() -> void:
	var input := Input.get_vector("move_left", "move_right", "move_up", "move_down")
	stretcher.set_input(-input.y, input.x)  # stick up = push, left/right = steer
	var hp: Vector3 = stretcher.handle_point()
	global_position = Vector3(hp.x, stretcher.global_position.y, hp.z)
	rotation.y = stretcher.global_rotation.y
	velocity = Vector3.ZERO
	if Input.is_action_just_pressed("grab"):
		_let_go()
	elif Input.is_action_just_pressed("interact"):
		_interact_pushing()
	elif Input.is_action_just_pressed("throw"):
		game.toast("Hands are on the stretcher. Let go [GRAB] to toss bags.", 1.8)
	_stretcher_buttons(true)


func _process_drive() -> void:
	var input := Input.get_vector("move_left", "move_right", "move_up", "move_down")
	ambulance.set_input(-input.y, input.x, Input.is_action_pressed("brake"))
	global_position = ambulance.driver_seat_point()
	velocity = Vector3.ZERO
	if Input.is_action_just_pressed("siren"):
		ambulance.toggle_siren()
		game.toast("Siren " + ("ON" if ambulance.siren_on else "OFF"), 1.2)
	if Input.is_action_just_pressed("interact"):
		if ambulance.speed() < 3.0:
			_exit_vehicle()
		else:
			game.toast("Slow down to get out", 1.5)


# ---------------------------------------------------------------- actions

func _interact_on_foot() -> void:
	if held_prop == null and _flat_dist(ambulance.driver_door_point()) < 1.8:
		_enter_vehicle()
		return
	if stretcher.stowed and ambulance.is_in_rear_zone(global_position):
		_unload_stretcher()
		return
	if _patient_nearby(2.8):
		_try_transfer_patient()
		return
	game.toast("Nothing to use here", 1.2)


func _interact_pushing() -> void:
	if game.is_at_er(stretcher.global_position):
		if stretcher.pad.has_patient():
			game.deliver()
		else:
			game.toast("No patient on the stretcher", 1.5)
		return
	if ambulance.is_in_rear_zone(stretcher.global_position):
		if stretcher.height_index != HEIGHT_LOW:
			game.toast("Lower the stretcher to LOW to slide it in", 1.8)
			return
		_let_go()
		stretcher.stow.call_deferred(ambulance.stow_point)
		game.toast("Stretcher loaded. Hop in and drive!", 2.0)
		return
	if _patient_nearby(3.6):
		_try_transfer_patient()
		return
	game.toast("Push to the patient, the ambulance's back doors or the ER", 2.0)


func _grab_on_foot() -> void:
	if held_prop != null:
		_drop()
		return
	if not stretcher.stowed and _flat_dist(stretcher.handle_point()) < grab_reach:
		_take_stretcher()
		return
	var bag = _nearest_bag()
	if bag != null:
		_pick_up(bag)
		return
	if not stretcher.stowed and _flat_dist(stretcher.global_position) < 2.6:
		_take_stretcher()
		return
	game.toast("Nothing to grab", 1.0)


func _take_stretcher() -> void:
	mode = Mode.PUSH
	stretcher.set_held(true)
	cam.set_target(stretcher, "push")


func _let_go() -> void:
	mode = Mode.WALK
	stretcher.set_held(false)
	cam.set_target(self, "walk")


func _try_transfer_patient() -> void:
	var p = game.current_patient
	if stretcher.stowed:
		game.toast("Unload the stretcher from the ambulance first", 2.0)
		return
	var sp: Vector3 = stretcher.global_position
	var pp: Vector3 = p.global_position
	if Vector2(sp.x - pp.x, sp.z - pp.z).length() > 3.2:
		game.toast("Bring the stretcher right next to the patient", 2.0)
		return
	if stretcher.height_index != HEIGHT_LOW:
		game.toast("Lower the stretcher to LOW first", 1.8)
		return
	stretcher.pad.stick.call_deferred(p)
	game.toast("Patient transferred onto the stretcher", 2.0)


func _unload_stretcher() -> void:
	var facing: Basis = ambulance.global_basis.rotated(Vector3.UP, PI)
	var at := Transform3D(facing, ambulance.rear_point() + Vector3.UP * 0.1)
	stretcher.unstow.call_deferred(game.world, at)
	_take_stretcher.call_deferred()  # you come out holding it
	game.toast("Stretcher out. Push it to the patient.", 2.0)


func _enter_vehicle() -> void:
	mode = Mode.DRIVE
	visible = false
	collision_layer = 0
	collision_mask = 0
	ambulance.driven = true
	cam.set_target(ambulance, "drive")
	game.toast("Driving: SIREN for lights, BRAKE to slide, USE to get out", 3.0)


func _exit_vehicle() -> void:
	ambulance.driven = false
	ambulance.set_input(0.0, 0.0, true)
	global_position = ambulance.driver_door_point() + Vector3.UP * 0.2
	rotation.y = ambulance.global_rotation.y
	velocity = Vector3.ZERO
	collision_layer = LAYER_PLAYER
	collision_mask = MASK_PLAYER
	visible = true
	mode = Mode.WALK
	cam.set_target(self, "walk")


# ---------------------------------------------------------------- bags

func _nearest_bag():
	var best = null
	var best_d := reach
	var bags: Array = get_tree().get_nodes_in_group("bag")
	for b in bags:
		if b.is_held:
			continue
		var d := _flat_dist(b.global_position)
		if d < best_d:
			best_d = d
			best = b
	return best


func _pick_up(bag) -> void:
	held_prop = bag
	bag.is_held = true
	if bag.is_stuck:
		bag.get_parent().detach(bag)  # peel it off the sticky pad
	_attach_to_hand.call_deferred(bag)


func _attach_to_hand(bag) -> void:
	if not is_instance_valid(bag):
		return
	bag.set_physics_enabled(false)
	bag.reparent(hand, false)
	bag.position = Vector3.ZERO
	bag.rotation = Vector3.ZERO
	game.toast("Picked up: %s" % bag.label, 1.2)


func _drop() -> void:
	var bag = held_prop
	held_prop = null
	_launch.call_deferred(bag, -global_basis.z * 1.2 + Vector3.UP * 1.2)


func _throw() -> void:
	if held_prop == null:
		game.toast("Pick up a bag first [GRAB]", 1.2)
		return
	var bag = held_prop
	held_prop = null
	_launch.call_deferred(bag, _throw_velocity())


func _launch(bag, v: Vector3) -> void:
	if not is_instance_valid(bag):
		return
	bag.reparent(game.world, true)
	bag.is_held = false
	bag.set_physics_enabled(true)
	bag.linear_velocity = v
	bag.angular_velocity = Vector3(randf_range(-4.0, 4.0), randf_range(-4.0, 4.0), randf_range(-4.0, 4.0))


## Toss assist: if the stretcher is roughly in front, solve a ballistic arc
## that lands on the sticky pad. Otherwise throw straight ahead.
func _throw_velocity() -> Vector3:
	var fwd := -global_basis.z
	fwd.y = 0.0
	fwd = fwd.normalized()
	var from := hand.global_position
	if not stretcher.stowed:
		var target: Vector3 = stretcher.pad_center() + Vector3.UP * 0.25
		var to := target - from
		var flat := Vector3(to.x, 0.0, to.z)
		var dist := flat.length()
		if dist > 0.4 and dist < auto_aim_range and rad_to_deg(fwd.angle_to(flat)) < auto_aim_angle:
			var t := clampf(dist / 6.0, 0.35, 0.95)
			var v := flat / t
			v.y = (to.y + 0.5 * 9.8 * t * t) / t
			return v
	return fwd * throw_speed + Vector3.UP * throw_lift


# ---------------------------------------------------------------- helpers

func _stretcher_buttons(active: bool) -> void:
	if not active or stretcher.stowed:
		return
	if Input.is_action_just_pressed("raise"):
		game.toast("Stretcher: " + stretcher.raise(), 1.2)
	elif Input.is_action_just_pressed("lower"):
		game.toast("Stretcher: " + stretcher.lower(), 1.2)
	elif Input.is_action_just_pressed("release_pad"):
		var n: int = stretcher.pad.stuck.size()
		if n == 0:
			game.toast("Sticky pad is empty", 1.0)
		else:
			stretcher.pad.release_all.call_deferred(game.world, stretcher.global_basis.x)
			game.toast("Sticky pad released %d item(s)" % n, 1.5)


func _near_stretcher() -> bool:
	return not stretcher.stowed and _flat_dist(stretcher.global_position) < 3.0


func _patient_nearby(radius: float) -> bool:
	var p = game.current_patient
	return p != null and is_instance_valid(p) and not p.is_stuck and _flat_dist(p.global_position) < radius


func _flat_dist(p: Vector3) -> float:
	return Vector2(p.x - global_position.x, p.z - global_position.z).length()


func _context_hint() -> String:
	match mode:
		Mode.DRIVE:
			return "MOVE: drive   BRAKE: handbrake slide   SIREN: lights   USE: get out"
		Mode.PUSH:
			if game.is_at_er(stretcher.global_position) and stretcher.pad.has_patient():
				return "USE: hand the patient over to the ER"
			if ambulance.is_in_rear_zone(stretcher.global_position):
				return "USE: load the stretcher (must be LOW)"
			if _patient_nearby(3.6):
				return "USE: transfer the patient (must be LOW)"
			return "MOVE: push and steer   RAISE/LOWER: height   UNSTICK: release pad   GRAB: let go"
	if held_prop != null:
		return "TOSS: throw the %s (auto-aims at the sticky pad)   GRAB: set it down" % held_prop.label
	if _flat_dist(ambulance.driver_door_point()) < 1.8:
		return "USE: drive the ambulance"
	if stretcher.stowed and ambulance.is_in_rear_zone(global_position):
		return "USE: unload the stretcher"
	if _near_stretcher():
		return "GRAB: push the stretcher   RAISE/LOWER: height   UNSTICK: release pad"
	if _nearest_bag() != null:
		return "GRAB: pick up the bag"
	if _patient_nearby(2.8):
		return "Bring the stretcher here, set it LOW, then USE"
	return ""


func _mat(c: Color) -> StandardMaterial3D:
	var m := StandardMaterial3D.new()
	m.albedo_color = c
	m.roughness = 0.7
	return m


func _build() -> void:
	var shape := CapsuleShape3D.new()
	shape.radius = 0.35
	shape.height = 1.8
	var cs := CollisionShape3D.new()
	cs.shape = shape
	cs.position.y = 0.9
	add_child(cs)
	var body := MeshInstance3D.new()
	var cap := CapsuleMesh.new()
	cap.radius = 0.35
	cap.height = 1.45
	body.mesh = cap
	body.position.y = 0.75
	body.material_override = _mat(Color(0.12, 0.2, 0.45))
	add_child(body)
	var vest := MeshInstance3D.new()
	var vm := CylinderMesh.new()
	vm.top_radius = 0.37
	vm.bottom_radius = 0.37
	vm.height = 0.12
	vest.mesh = vm
	vest.position.y = 1.0
	vest.material_override = _mat(Color(0.95, 0.95, 0.2))
	add_child(vest)
	var head := MeshInstance3D.new()
	var sm := SphereMesh.new()
	sm.radius = 0.24
	sm.height = 0.48
	head.mesh = sm
	head.position.y = 1.68
	head.material_override = _mat(Color(0.95, 0.78, 0.62))
	add_child(head)
	var cap_brim := MeshInstance3D.new()
	var bm := BoxMesh.new()
	bm.size = Vector3(0.3, 0.05, 0.2)
	cap_brim.mesh = bm
	cap_brim.position = Vector3(0, 1.86, -0.22)  # shows which way you face
	cap_brim.material_override = _mat(Color(0.12, 0.2, 0.45))
	add_child(cap_brim)
	hand = Node3D.new()
	hand.name = "Hand"
	hand.position = Vector3(0, 1.15, -0.62)
	add_child(hand)
