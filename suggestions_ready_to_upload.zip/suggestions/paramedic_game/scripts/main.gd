extends Node3D
## Paramedic Rush — suggestion prototype for Xogot (Godot 4.4+, GDScript only).
##
## Everything (town, hospital, ambulance, stretcher, props, HUD, touch controls)
## is built in code from primitive meshes, so the project needs no imported
## assets and opens the same way in Xogot on iPad/iPhone and in desktop Godot.
##
## Game loop: a call comes in -> drive to the red beacon -> unload the
## stretcher -> toss the scattered bags onto its sticky pad -> lower it and
## transfer the patient -> load it back into the ambulance -> drive to the
## hospital -> push it up the ER ramp -> hand over. Faster + more bags = more points.

const InputSetup := preload("res://scripts/input_setup.gd")
const AmbulanceScript := preload("res://scripts/ambulance.gd")
const StretcherScript := preload("res://scripts/stretcher.gd")
const ParamedicScript := preload("res://scripts/paramedic.gd")
const PropScript := preload("res://scripts/prop.gd")
const FollowCameraScript := preload("res://scripts/follow_camera.gd")
const TouchControlsScript := preload("res://scripts/touch_controls.gd")

const LAYER_WORLD := 1 << 0
const ROAD_LINES := [-80.0, -40.0, 0.0, 40.0, 80.0]
const BLOCK_CENTERS := [-60.0, -20.0, 20.0, 60.0]
const HOSPITAL_BLOCK := Vector2(-20.0, -60.0)
const AMBULANCE_SPAWN := Vector3(-28.0, 0.3, -40.0)

@export var town_seed: int = 7
@export var delivery_points: int = 500
@export var time_bonus_window: float = 150.0   # seconds before the time bonus runs out
@export var time_bonus_per_second: float = 4.0
@export var points_per_bag: int = 100
@export var bags_per_call_min: int = 2
@export var bags_per_call_max: int = 4

var world: Node3D
var ambulance
var stretcher
var player
var cam
var current_patient = null
var call_number: int = 0
var call_time: float = 0.0
var score: int = 0
var er_point: Vector3 = Vector3(-20.0, 1.0, -54.0)

var _kits: Array = [
	{"label": "trauma bag", "color": Color(0.86, 0.16, 0.16), "mass": 7.0, "size": Vector3(0.7, 0.38, 0.45)},
	{"label": "oxygen kit", "color": Color(0.12, 0.66, 0.32), "mass": 9.0, "size": Vector3(0.55, 0.34, 0.4)},
	{"label": "cardiac monitor", "color": Color(0.96, 0.76, 0.12), "mass": 8.0, "size": Vector3(0.5, 0.42, 0.36)},
	{"label": "patient's backpack", "color": Color(0.3, 0.36, 0.82), "mass": 4.0, "size": Vector3(0.45, 0.42, 0.3)},
]
var _spawns: Array = []      # [{pos: Vector3, out: Vector3}]
var _call_props: Array = []
var _beacon: MeshInstance3D
var _beacon_mat: StandardMaterial3D
var _hud_top: Label
var _hud_status: Label
var _hud_hint: Label
var _hud_toast: Label
var _toast_time: float = 0.0
var _next_call_in: float = 0.0
var _mat_cache: Dictionary = {}
var _rng := RandomNumberGenerator.new()


func _ready() -> void:
	InputSetup.setup()
	_rng.seed = town_seed
	world = self
	_build_environment()
	_build_ground_and_roads()
	_build_town()
	_build_hospital()
	_build_fun_ramps()
	_spawn_actors()
	_build_hud()
	_build_beacon()
	_start_call()


func _process(delta: float) -> void:
	if current_patient != null and is_instance_valid(current_patient):
		call_time += delta
	if _next_call_in > 0.0:
		_next_call_in -= delta
		if _next_call_in <= 0.0:
			_start_call()
	if _toast_time > 0.0:
		_toast_time -= delta
		_hud_toast.modulate.a = clampf(_toast_time, 0.0, 1.0)
	_update_doors()
	_update_beacon()
	_update_hud()
	_safety_nets()


# ---------------------------------------------------------------- calls

func _start_call() -> void:
	call_number += 1
	call_time = 0.0
	var amb_pos: Vector3 = ambulance.global_position
	var options: Array = []
	for s in _spawns:
		var p: Vector3 = s["pos"]
		if p.distance_to(amb_pos) > 45.0:
			options.append(s)
	if options.is_empty():
		options = _spawns
	var spot: Dictionary = options[_rng.randi_range(0, options.size() - 1)]
	var pos: Vector3 = spot["pos"]
	var out: Vector3 = spot["out"]
	var side := out.cross(Vector3.UP)

	var patient = PropScript.new()
	patient.kind = "patient"
	patient.label = "patient"
	patient.prop_mass = 70.0
	patient.color = Color.from_hsv(_rng.randf(), 0.5, 0.85)
	add_child(patient)
	patient.global_position = pos + Vector3.UP * 0.26
	patient.rotation.y = _rng.randf_range(-PI, PI)
	patient.freeze = true  # lies still until transferred
	current_patient = patient
	_call_props = [patient]

	# Bags scattered toward the road side; toss them onto the stretcher for points.
	var count := _rng.randi_range(bags_per_call_min, bags_per_call_max)
	for i in count:
		var kit: Dictionary = _kits[i % _kits.size()]
		var bag = PropScript.new()
		bag.kind = "bag"
		bag.label = kit["label"]
		bag.color = kit["color"]
		bag.prop_mass = kit["mass"]
		bag.size = kit["size"]
		add_child(bag)
		bag.global_position = pos + out * _rng.randf_range(1.8, 3.4) + side * _rng.randf_range(-2.2, 2.2) + Vector3.UP * 0.5
		bag.rotation.y = _rng.randf_range(-PI, PI)
		_call_props.append(bag)
	toast("CALL #%d: patient down! Follow the red beacon." % call_number, 4.0)


func is_at_er(pos: Vector3) -> bool:
	return Vector2(pos.x - er_point.x, pos.z - er_point.z).length() < 3.0 and pos.y > er_point.y - 0.4


func deliver() -> void:
	var bags: int = stretcher.pad.count_kind("bag")
	var time_bonus := int(maxf(0.0, time_bonus_window - call_time) * time_bonus_per_second)
	var points := delivery_points + time_bonus + bags * points_per_bag
	score += points
	toast("Patient handed over! +%d   (speed +%d, bags %d x %d)" % [points, time_bonus, bags, points_per_bag], 4.0)
	stretcher.pad.clear_and_free()
	for p in _call_props:
		if is_instance_valid(p) and not p.is_held and not p.is_stuck:
			p.queue_free()
	_call_props.clear()
	current_patient = null
	_next_call_in = 3.0


func objective() -> Dictionary:
	if current_patient == null or not is_instance_valid(current_patient):
		return {}
	if current_patient.is_stuck:
		return {"pos": er_point, "name": "Hospital ER", "color": Color(0.2, 1.0, 0.4)}
	return {"pos": current_patient.global_position, "name": "Patient", "color": Color(1.0, 0.2, 0.2)}


# ---------------------------------------------------------------- HUD

func set_hint(text: String) -> void:
	if _hud_hint != null:
		_hud_hint.text = text


func toast(text: String, duration: float = 2.5) -> void:
	if _hud_toast == null:
		return
	_hud_toast.text = text
	_toast_time = duration
	_hud_toast.modulate.a = 1.0


func _update_hud() -> void:
	var mins := floori(call_time / 60.0)
	var secs := floori(call_time) % 60
	var obj := objective()
	var line2 := "Waiting for the next call..."
	if not obj.is_empty():
		var target: Vector3 = obj["pos"]
		line2 = "%s: %d m" % [obj["name"], int(player.global_position.distance_to(target))]
	_hud_top.text = "CALL #%d    TIME %02d:%02d    SCORE %d\n%s" % [call_number, mins, secs, score, line2]

	var mode_names := ["ON FOOT", "PUSHING STRETCHER", "DRIVING"]
	var s := "%s\nStretcher: %s\nLoad: %d kg" % [mode_names[player.mode], stretcher.height_name(), int(stretcher.total_mass())]
	if stretcher.stowed:
		s += "  (in ambulance)"
	if player.mode == ParamedicScript.Mode.DRIVE:
		s += "\n%d km/h   Siren %s" % [int(ambulance.speed() * 3.6), "ON" if ambulance.siren_on else "OFF"]
	if stretcher.top_heavy_warning:
		s += "\nTOP-HEAVY! Slow down or lower it"
	_hud_status.text = s


func _update_beacon() -> void:
	var obj := objective()
	if obj.is_empty():
		_beacon.visible = false
		return
	var pos: Vector3 = obj["pos"]
	var col: Color = obj["color"]
	_beacon.visible = true
	_beacon.global_position = Vector3(pos.x, 20.0, pos.z)
	var d: float = cam.global_position.distance_to(pos)
	col.a = clampf(d / 60.0, 0.06, 0.4)
	_beacon_mat.albedo_color = col


func _update_doors() -> void:
	var near := false
	if player.mode != ParamedicScript.Mode.DRIVE:
		near = ambulance.is_in_rear_zone(player.global_position)
		if not stretcher.stowed and ambulance.is_in_rear_zone(stretcher.global_position):
			near = true
	ambulance.doors_open = near


func _safety_nets() -> void:
	if player.mode != ParamedicScript.Mode.DRIVE and player.global_position.y < -15.0:
		player.global_position = ambulance.driver_door_point() + Vector3.UP * 0.5
		player.velocity = Vector3.ZERO
	if ambulance.global_position.y < -15.0:
		ambulance.global_position = AMBULANCE_SPAWN
		ambulance.velocity = Vector3.ZERO
	if not stretcher.stowed and stretcher.global_position.y < -15.0:
		stretcher.global_position = ambulance.rear_point() + Vector3.UP * 0.5
	for p in _call_props:
		if is_instance_valid(p) and not p.is_stuck and not p.is_held and p.global_position.y < -15.0:
			p.queue_free()


# ---------------------------------------------------------------- building the world

func _mat(color: Color) -> StandardMaterial3D:
	if _mat_cache.has(color):
		return _mat_cache[color]
	var m := StandardMaterial3D.new()
	m.albedo_color = color
	m.roughness = 0.85
	_mat_cache[color] = m
	return m


func _static_box(pos: Vector3, box_size: Vector3, color: Color) -> StaticBody3D:
	var sb := StaticBody3D.new()
	sb.collision_layer = LAYER_WORLD
	sb.collision_mask = 0
	sb.position = pos
	var mi := MeshInstance3D.new()
	var bm := BoxMesh.new()
	bm.size = box_size
	mi.mesh = bm
	mi.material_override = _mat(color)
	sb.add_child(mi)
	var cs := CollisionShape3D.new()
	var shape := BoxShape3D.new()
	shape.size = box_size
	cs.shape = shape
	sb.add_child(cs)
	add_child(sb)
	return sb


func _visual_box(pos: Vector3, box_size: Vector3, color: Color) -> MeshInstance3D:
	var mi := MeshInstance3D.new()
	var bm := BoxMesh.new()
	bm.size = box_size
	mi.mesh = bm
	mi.material_override = _mat(color)
	mi.position = pos
	mi.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
	add_child(mi)
	return mi


## A solid wedge whose top surface runs from `low` (on the ground) up to `high`.
func _ramp(low: Vector3, high: Vector3, width: float, thickness: float, color: Color, extend: float = 0.6) -> void:
	var fwd := (high - low).normalized()
	var right := fwd.cross(Vector3.UP).normalized()
	var up := right.cross(fwd).normalized()
	var length := low.distance_to(high) + extend
	var center := (low + high) * 0.5 - fwd * (extend * 0.5) - up * (thickness * 0.5)
	var sb := StaticBody3D.new()
	sb.collision_layer = LAYER_WORLD
	sb.collision_mask = 0
	sb.transform = Transform3D(Basis(right, up, -fwd), center)
	var mi := MeshInstance3D.new()
	var bm := BoxMesh.new()
	bm.size = Vector3(width, thickness, length)
	mi.mesh = bm
	mi.material_override = _mat(color)
	sb.add_child(mi)
	var cs := CollisionShape3D.new()
	var shape := BoxShape3D.new()
	shape.size = bm.size
	cs.shape = shape
	sb.add_child(cs)
	add_child(sb)


func _build_environment() -> void:
	var env := Environment.new()
	env.background_mode = Environment.BG_SKY
	var sky := Sky.new()
	var sky_mat := ProceduralSkyMaterial.new()
	sky_mat.sky_top_color = Color(0.3, 0.55, 0.95)
	sky_mat.sky_horizon_color = Color(0.75, 0.87, 1.0)
	sky_mat.ground_horizon_color = Color(0.75, 0.87, 1.0)
	sky_mat.ground_bottom_color = Color(0.35, 0.45, 0.35)
	sky.sky_material = sky_mat
	env.sky = sky
	env.ambient_light_source = Environment.AMBIENT_SOURCE_SKY
	env.ambient_light_energy = 0.45
	env.tonemap_mode = Environment.TONE_MAPPER_FILMIC
	env.glow_enabled = true  # makes the siren lights pop
	env.glow_intensity = 0.5
	env.glow_hdr_threshold = 1.5  # only truly bright things (sirens) bloom
	var we := WorldEnvironment.new()
	we.environment = env
	add_child(we)
	var sun := DirectionalLight3D.new()
	sun.rotation_degrees = Vector3(-55.0, -35.0, 0.0)
	sun.light_energy = 1.1
	sun.shadow_enabled = true
	sun.directional_shadow_max_distance = 80.0
	add_child(sun)


func _build_ground_and_roads() -> void:
	_static_box(Vector3(0, -0.5, 0), Vector3(240, 1, 240), Color(0.42, 0.68, 0.32))
	var asphalt := Color(0.27, 0.27, 0.3)
	for r in ROAD_LINES:
		_visual_box(Vector3(r, 0.01, 0), Vector3(12, 0.02, 200), asphalt)
		_visual_box(Vector3(0, 0.012, r), Vector3(200, 0.02, 12), asphalt)
		var t := -96.0
		while t < 96.0:
			_visual_box(Vector3(r, 0.025, t), Vector3(0.25, 0.02, 3.0), Color(1, 1, 1))
			_visual_box(Vector3(t, 0.026, r), Vector3(3.0, 0.02, 0.25), Color(1, 1, 1))
			t += 8.0


func _build_town() -> void:
	for bx in BLOCK_CENTERS:
		for bz in BLOCK_CENTERS:
			if Vector2(bx, bz) == HOSPITAL_BLOCK:
				continue
			var w := _rng.randf_range(14.0, 22.0)
			var d := _rng.randf_range(14.0, 22.0)
			var h := _rng.randf_range(5.0, 20.0)
			var col := Color.from_hsv(_rng.randf(), 0.35, 0.95)
			_static_box(Vector3(bx, h * 0.5, bz), Vector3(w, h, d), col)
			_visual_box(Vector3(bx, h + 0.2, bz), Vector3(w + 0.4, 0.4, d + 0.4), col.darkened(0.25))
			for out in [Vector3.RIGHT, Vector3.LEFT, Vector3.FORWARD, Vector3.BACK]:
				_spawns.append({"pos": Vector3(bx, 0.0, bz) + out * 12.5, "out": out})


func _build_hospital() -> void:
	var c := HOSPITAL_BLOCK
	var red := Color(0.9, 0.1, 0.1)
	_static_box(Vector3(c.x, 6.0, c.y - 4.0), Vector3(24, 12, 16), Color(0.95, 0.95, 0.97))
	_visual_box(Vector3(c.x, 9.0, c.y + 4.06), Vector3(4.5, 1.4, 0.1), red)
	_visual_box(Vector3(c.x, 9.0, c.y + 4.07), Vector3(1.4, 4.5, 0.1), red)
	_visual_box(Vector3(c.x, 2.25, c.y + 4.05), Vector3(4.0, 2.5, 0.1), Color(0.35, 0.6, 0.8))  # ER doors
	var sign_label := Label3D.new()
	sign_label.text = "EMERGENCY"
	sign_label.font_size = 96
	sign_label.pixel_size = 0.01
	sign_label.modulate = red
	sign_label.outline_size = 12
	sign_label.position = Vector3(c.x, 4.3, c.y + 4.12)
	add_child(sign_label)
	# Loading dock 1 m up, reached by a ramp: a heavy stretcher feels this.
	_static_box(Vector3(c.x, 0.5, -54.0), Vector3(12, 1, 4), Color(0.7, 0.7, 0.72))
	_ramp(Vector3(c.x, 0.0, -46.0), Vector3(c.x, 1.0, -52.0), 5.0, 1.2, Color(0.6, 0.6, 0.62))
	_visual_box(Vector3(c.x, 1.015, -54.0), Vector3(4.0, 0.02, 3.0), Color(0.2, 0.9, 0.4))  # hand-over zone
	er_point = Vector3(c.x, 1.0, -54.0)


func _build_fun_ramps() -> void:
	var orange := Color(1.0, 0.55, 0.1)
	_ramp(Vector3(-66.0, 0.0, 0.0), Vector3(-56.0, 1.8, 0.0), 7.0, 3.0, orange)
	_ramp(Vector3(40.0, 0.0, 22.0), Vector3(40.0, 1.6, 31.0), 7.0, 3.0, orange)
	_ramp(Vector3(0.0, 0.0, 48.0), Vector3(0.0, 1.2, 55.0), 7.0, 2.5, orange)


func _spawn_actors() -> void:
	ambulance = AmbulanceScript.new()
	ambulance.name = "Ambulance"
	add_child(ambulance)
	ambulance.global_position = AMBULANCE_SPAWN
	ambulance.rotation.y = -PI * 0.5  # facing +X along the road

	stretcher = StretcherScript.new()
	stretcher.name = "Stretcher"
	add_child(stretcher)
	stretcher.snap_height(StretcherScript.HEIGHT_LOW)
	stretcher.stow(ambulance.stow_point)  # starts loaded in the ambulance

	cam = FollowCameraScript.new()
	cam.name = "Camera"
	add_child(cam)
	cam.current = true

	player = ParamedicScript.new()
	player.name = "Paramedic"
	player.game = self
	player.ambulance = ambulance
	player.stretcher = stretcher
	player.cam = cam
	add_child(player)
	player.global_position = ambulance.driver_door_point() + Vector3.UP * 0.1
	player.rotation.y = ambulance.rotation.y

	cam.set_target(player, "walk")
	cam.yaw = player.rotation.y
	cam.snap()


func _build_hud() -> void:
	var layer := CanvasLayer.new()
	add_child(layer)
	var touch := TouchControlsScript.new()
	touch.name = "TouchControls"
	layer.add_child(touch)
	touch.camera_drag.connect(cam.orbit)
	_hud_top = _make_label(layer, Control.PRESET_TOP_WIDE, 24, HORIZONTAL_ALIGNMENT_LEFT, 12.0)
	_hud_status = _make_label(layer, Control.PRESET_TOP_WIDE, 20, HORIZONTAL_ALIGNMENT_RIGHT, 12.0)
	_hud_hint = _make_label(layer, Control.PRESET_TOP_WIDE, 20, HORIZONTAL_ALIGNMENT_CENTER, 96.0)
	_hud_hint.add_theme_color_override("font_color", Color(1.0, 0.95, 0.6))
	_hud_toast = _make_label(layer, Control.PRESET_HCENTER_WIDE, 28, HORIZONTAL_ALIGNMENT_CENTER, -140.0)


func _make_label(parent: Node, preset: int, font_size: int, align: int, top: float) -> Label:
	var l := Label.new()
	parent.add_child(l)
	l.set_anchors_and_offsets_preset(preset)
	l.offset_left = 16.0
	l.offset_right = -16.0
	l.offset_top = top
	l.horizontal_alignment = align
	l.mouse_filter = Control.MOUSE_FILTER_IGNORE
	l.add_theme_font_size_override("font_size", font_size)
	l.add_theme_constant_override("outline_size", 8)
	l.add_theme_color_override("font_outline_color", Color(0, 0, 0, 0.85))
	return l


func _build_beacon() -> void:
	_beacon = MeshInstance3D.new()
	var cyl := CylinderMesh.new()
	cyl.top_radius = 0.7
	cyl.bottom_radius = 0.7
	cyl.height = 40.0
	_beacon.mesh = cyl
	_beacon_mat = StandardMaterial3D.new()
	_beacon_mat.shading_mode = BaseMaterial3D.SHADING_MODE_UNSHADED
	_beacon_mat.transparency = BaseMaterial3D.TRANSPARENCY_ALPHA
	_beacon_mat.cull_mode = BaseMaterial3D.CULL_DISABLED
	_beacon_mat.albedo_color = Color(1, 0.2, 0.2, 0.35)
	_beacon.material_override = _beacon_mat
	_beacon.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
	add_child(_beacon)
