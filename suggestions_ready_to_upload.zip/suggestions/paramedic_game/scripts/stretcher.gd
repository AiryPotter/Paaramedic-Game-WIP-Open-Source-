extends CharacterBody3D
## Sim-style stretcher: big and wide so tossed bags land easily, three deck
## heights, mass-aware pushing (heavier = slower to start, stop and turn),
## real slope gravity on ramps, a top-heavy wobble, and a sticky pad.

const StickyPad := preload("res://scripts/sticky_pad.gd")

const LAYER_STRETCHER := 1 << 3
const MASK_STRETCHER := (1 << 0) | (1 << 1)  # world, vehicle
const HEIGHT_LOW := 0
const HEIGHT_MID := 1
const HEIGHT_HIGH := 2
const HEIGHT_NAMES := ["LOW (load)", "MID (transport)", "HIGH (bedside)"]

@export var deck_heights: Array[float] = [0.45, 0.8, 1.05]
@export var deck_size: Vector2 = Vector2(1.25, 2.35)  # width x length, oversized on purpose
@export var base_mass: float = 45.0           # kg, empty stretcher
@export var push_force: float = 620.0         # N from the paramedic (starting shove)
@export var push_power: float = 320.0         # W a person can sustain: caps speed up ramps
@export var rolling_resistance: float = 0.04  # wheel drag as a fraction of weight
@export var max_push_speed: float = 4.2       # m/s
@export var reverse_factor: float = 0.6
@export var turn_rate: float = 1.8            # rad/s when empty and rolling
@export var lift_speed: float = 0.8           # m/s deck travel when empty
@export var hold_brake: float = 7.0           # how hard the medic holds it still
@export var slope_gravity: float = 9.8
@export var high_height_speed_factor: float = 0.7

var height_index: int = HEIGHT_MID
var deck_y: float = 0.8
var held: bool = false
var stowed: bool = false
var top_heavy_warning: bool = false
var pad  # sticky_pad.gd

var _throttle: float = 0.0
var _steer: float = 0.0
var _fwd_speed: float = 0.0
var _deck: Node3D
var _shape: BoxShape3D
var _shape_node: CollisionShape3D
var _legs: Array[MeshInstance3D] = []
var _wobble_t: float = 0.0


func _ready() -> void:
	collision_layer = LAYER_STRETCHER
	collision_mask = MASK_STRETCHER
	floor_snap_length = 0.35
	floor_max_angle = deg_to_rad(30.0)
	deck_y = deck_heights[height_index]
	_build()
	_apply_deck_height()


# ---------------------------------------------------------------- public API

func set_input(throttle: float, steer: float) -> void:
	_throttle = clampf(throttle, -1.0, 1.0)
	_steer = clampf(steer, -1.0, 1.0)


func set_held(on: bool) -> void:
	held = on
	if not on:
		set_input(0.0, 0.0)


func raise() -> String:
	height_index = mini(height_index + 1, HEIGHT_HIGH)
	return height_name()


func lower() -> String:
	height_index = maxi(height_index - 1, HEIGHT_LOW)
	return height_name()


func snap_height(index: int) -> void:
	height_index = clampi(index, HEIGHT_LOW, HEIGHT_HIGH)
	deck_y = deck_heights[height_index]
	_apply_deck_height()


func height_name() -> String:
	return HEIGHT_NAMES[height_index]


func total_mass() -> float:
	return base_mass + pad.total_mass()


func handle_point() -> Vector3:
	return global_transform * Vector3(0.0, 0.0, deck_size.y * 0.5 + 0.55)


func pad_center() -> Vector3:
	return pad.global_position


## Slide into the ambulance (call deferred: it reparents a physics body).
func stow(point: Node3D) -> void:
	set_held(false)
	stowed = true
	_fwd_speed = 0.0
	velocity = Vector3.ZERO
	collision_layer = 0
	collision_mask = 0
	reparent(point, false)
	transform = Transform3D.IDENTITY


func unstow(world: Node, at: Transform3D) -> void:
	reparent(world, false)
	global_transform = at
	stowed = false
	collision_layer = LAYER_STRETCHER
	collision_mask = MASK_STRETCHER


# ---------------------------------------------------------------- simulation

func _physics_process(delta: float) -> void:
	if stowed:
		return
	_update_lift(delta)
	var total := total_mass()
	if held:
		# Heavier loads and slow speeds turn more slowly (casters fight you).
		var heaviness := sqrt(base_mass / total)
		var pivot_ease := 0.45 + 0.55 * clampf(absf(_fwd_speed) / max_push_speed, 0.0, 1.0)
		rotate_y(-_steer * turn_rate * heaviness * pivot_ease * delta)
	var fwd := -global_basis.z
	fwd.y = 0.0
	fwd = fwd.normalized()
	if held:
		var grade := 0.0  # + when facing downhill, - when facing uphill
		if is_on_floor():
			var n := get_floor_normal()
			grade = fwd.dot(Vector3(n.x, 0.0, n.z))
		# Human push: strong shove from standstill, then limited by power (F = P / v),
		# so a loaded stretcher crawls up a ramp while an empty one rolls easily.
		var drive := minf(push_force, push_power / maxf(absf(_fwd_speed), 0.4)) * _throttle
		_fwd_speed += (drive / total + slope_gravity * grade) * delta
		_fwd_speed = move_toward(_fwd_speed, 0.0, rolling_resistance * 9.8 * delta)
		if absf(_throttle) < 0.05:
			_fwd_speed = move_toward(_fwd_speed, 0.0, hold_brake * delta)
		var vmax := max_push_speed * (high_height_speed_factor if height_index == HEIGHT_HIGH else 1.0)
		_fwd_speed = clampf(_fwd_speed, -vmax * reverse_factor, vmax)
		top_heavy_warning = height_index == HEIGHT_HIGH and absf(_steer) > 0.5 \
				and absf(_fwd_speed) > 2.0 and total > base_mass + 40.0
	else:
		_fwd_speed = move_toward(_fwd_speed, 0.0, 25.0 * delta)  # wheel locks
		top_heavy_warning = false
	if not is_on_floor():
		velocity.y -= 9.8 * delta
	velocity.x = fwd.x * _fwd_speed
	velocity.z = fwd.z * _fwd_speed
	move_and_slide()
	var flat := Vector3(velocity.x, 0.0, velocity.z)
	_fwd_speed = flat.dot(fwd)  # walls and kerbs eat speed
	_animate(delta)


func _update_lift(delta: float) -> void:
	var target: float = deck_heights[height_index]
	if is_equal_approx(deck_y, target):
		return
	# A heavy patient makes the hydraulic lift slower.
	var rate := lift_speed * clampf(base_mass * 1.6 / total_mass(), 0.35, 1.0)
	deck_y = move_toward(deck_y, target, rate * delta)
	_apply_deck_height()


func _apply_deck_height() -> void:
	_deck.position.y = deck_y
	var h := deck_y + 0.05
	_shape.size = Vector3(deck_size.x, h, deck_size.y)
	_shape_node.position.y = h * 0.5
	var leg_len := maxf(deck_y - 0.24, 0.05)
	for leg in _legs:
		leg.scale.y = leg_len
		leg.position.y = 0.24 + leg_len * 0.5


func _animate(delta: float) -> void:
	if top_heavy_warning:
		_wobble_t += delta
		_deck.rotation.z = sin(_wobble_t * 18.0) * 0.06
	else:
		_deck.rotation.z = lerpf(_deck.rotation.z, 0.0, 1.0 - exp(-8.0 * delta))


# ---------------------------------------------------------------- build

func _mat(c: Color) -> StandardMaterial3D:
	var m := StandardMaterial3D.new()
	m.albedo_color = c
	m.roughness = 0.6
	return m


func _mesh_box(parent: Node3D, pos: Vector3, box_size: Vector3, c: Color) -> void:
	var mi := MeshInstance3D.new()
	var bm := BoxMesh.new()
	bm.size = box_size
	mi.mesh = bm
	mi.position = pos
	mi.material_override = _mat(c)
	parent.add_child(mi)


func _cylinder(parent: Node3D, pos: Vector3, radius: float, length: float, rot: Vector3, c: Color) -> MeshInstance3D:
	var mi := MeshInstance3D.new()
	var cm := CylinderMesh.new()
	cm.top_radius = radius
	cm.bottom_radius = radius
	cm.height = length
	mi.mesh = cm
	mi.position = pos
	mi.rotation = rot
	mi.material_override = _mat(c)
	parent.add_child(mi)
	return mi


func _build() -> void:
	var metal := Color(0.75, 0.77, 0.8)
	var dark := Color(0.15, 0.15, 0.17)
	var orange := Color(0.95, 0.4, 0.1)
	# Base frame and caster wheels.
	_mesh_box(self, Vector3(0, 0.24, 0), Vector3(deck_size.x * 0.8, 0.07, deck_size.y * 0.92), metal)
	for wz in [-1.0, 1.0]:
		for wx in [-1.0, 1.0]:
			_cylinder(self, Vector3(wx * deck_size.x * 0.36, 0.1, wz * deck_size.y * 0.42), 0.1, 0.08, Vector3(0, 0, PI * 0.5), dark)
	# Legs (stretched when the deck moves).
	for lz in [-1.0, 1.0]:
		for lx in [-1.0, 1.0]:
			_legs.append(_cylinder(self, Vector3(lx * deck_size.x * 0.3, 0.5, lz * deck_size.y * 0.3), 0.035, 1.0, Vector3.ZERO, metal))
	# Deck, side rails and push handle (+Z is the back / handle end).
	_deck = Node3D.new()
	add_child(_deck)
	_mesh_box(_deck, Vector3(0, 0.02, 0), Vector3(deck_size.x, 0.06, deck_size.y), dark)
	for sx in [-1.0, 1.0]:
		_mesh_box(_deck, Vector3(sx * (deck_size.x * 0.5 + 0.03), 0.14, 0), Vector3(0.05, 0.05, deck_size.y * 0.8), metal)
		_mesh_box(_deck, Vector3(sx * deck_size.x * 0.42, 0.17, deck_size.y * 0.5 + 0.12), Vector3(0.05, 0.05, 0.3), metal)
	_cylinder(_deck, Vector3(0, 0.3, deck_size.y * 0.5 + 0.26), 0.04, deck_size.x * 0.9, Vector3(0, 0, PI * 0.5), orange)
	# Sticky pad covers the whole deck.
	pad = StickyPad.new()
	pad.pad_size = Vector3(deck_size.x * 0.98, 0.05, deck_size.y * 0.98)
	pad.position = Vector3(0, 0.05, 0)
	_deck.add_child(pad)
	# Collision grows with the deck so loose props can rest on top.
	_shape = BoxShape3D.new()
	_shape_node = CollisionShape3D.new()
	_shape_node.shape = _shape
	add_child(_shape_node)
