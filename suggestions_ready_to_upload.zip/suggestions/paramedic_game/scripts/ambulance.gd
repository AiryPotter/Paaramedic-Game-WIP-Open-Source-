extends CharacterBody3D
## Cartoony, arcade-style ambulance. A simple kinematic driving model (no
## VehicleBody3D) with handbrake drifts, ramp jumps, squash-and-stretch,
## springy wall bounces, opening rear doors and a flashing light bar.

const LAYER_VEHICLE := 1 << 1
const MASK_VEHICLE := (1 << 0) | (1 << 3)  # world, stretcher (props get shoved aside)

@export var max_speed: float = 24.0        # m/s (~86 km/h)
@export var reverse_speed: float = 9.0
@export var acceleration: float = 11.0
@export var brake_force: float = 32.0
@export var coast_drag: float = 4.0
@export var steer_rate: float = 2.3        # rad/s at full lock
@export var grip: float = 7.0              # how fast sideways sliding dies out
@export var drift_grip: float = 1.4        # grip while the handbrake is held
@export var air_gravity: float = 24.0      # heavier than real = snappy cartoon jumps
@export var wall_bounce: float = 0.45
@export var squash_amount: float = 0.2
@export var pitch_amount: float = 0.012
@export var roll_amount: float = 0.006

var driven: bool = false
var siren_on: bool = false
var doors_open: bool = false
var stow_point: Node3D

var _throttle: float = 0.0
var _steer: float = 0.0
var _handbrake: bool = true
var _fwd_speed: float = 0.0
var _long_accel: float = 0.0
var _yaw_rate: float = 0.0
var _visual: Node3D
var _squash: float = 0.0
var _squash_vel: float = 0.0
var _was_on_floor: bool = true
var _last_air_vy: float = 0.0
var _wheel_spinners: Array[Node3D] = []
var _front_pivots: Array[Node3D] = []
var _door_pivots: Array[Node3D] = []
var _siren_lights: Array[OmniLight3D] = []
var _siren_mats: Array[StandardMaterial3D] = []
var _siren_t: float = 0.0


func _ready() -> void:
	collision_layer = LAYER_VEHICLE
	collision_mask = MASK_VEHICLE
	floor_snap_length = 0.25
	floor_max_angle = deg_to_rad(40.0)
	_build()


# ---------------------------------------------------------------- public API

func set_input(throttle: float, steer: float, handbrake: bool) -> void:
	_throttle = clampf(throttle, -1.0, 1.0)
	_steer = clampf(steer, -1.0, 1.0)
	_handbrake = handbrake


func toggle_siren() -> void:
	siren_on = not siren_on


func speed() -> float:
	return absf(_fwd_speed)


func driver_door_point() -> Vector3:
	return global_transform * Vector3(-1.9, 0.0, -1.6)


func driver_seat_point() -> Vector3:
	return global_transform * Vector3(-0.5, 1.0, -1.6)


func rear_point() -> Vector3:
	return global_transform * Vector3(0.0, 0.0, 5.0)


func is_in_rear_zone(p: Vector3) -> bool:
	var r := rear_point()
	return Vector2(p.x - r.x, p.z - r.z).length() < 2.4 and absf(p.y - r.y) < 1.5


# ---------------------------------------------------------------- driving

func _physics_process(delta: float) -> void:
	if not driven:
		_throttle = 0.0
		_steer = 0.0
		_handbrake = true
	var on_floor := is_on_floor()

	# 1) Steering. Needs some speed, eases off at top speed, flips in reverse.
	var speed_factor := clampf(absf(_fwd_speed) / 5.0, 0.0, 1.0)
	var top_speed_ease := 1.0 - 0.35 * clampf(absf(_fwd_speed) / max_speed, 0.0, 1.0)
	var target_yaw := _steer * steer_rate * speed_factor * top_speed_ease * signf(_fwd_speed)
	if _handbrake and driven and absf(_fwd_speed) > 6.0:
		target_yaw *= 1.5  # handbrake turn
	if not on_floor:
		target_yaw = _steer * 0.8  # a little air control
	_yaw_rate = lerpf(_yaw_rate, target_yaw, 1.0 - exp(-10.0 * delta))
	rotate_y(-_yaw_rate * delta)

	# 2) Measure velocity in the NEW heading: the leftover sideways part is the drift.
	var fwd := -global_basis.z
	fwd.y = 0.0
	fwd = fwd.normalized()
	var right := global_basis.x
	right.y = 0.0
	right = right.normalized()
	var f := velocity.dot(fwd)
	var lat := velocity.dot(right)
	var vy := velocity.y

	# 3) Engine, brakes and tyre grip (only with wheels on the ground).
	if on_floor:
		if _throttle > 0.05:
			var rate := acceleration if f >= -0.5 else brake_force
			f = move_toward(f, max_speed * _throttle, rate * delta)
		elif _throttle < -0.05:
			var rate := acceleration * 0.8 if f <= 0.5 else brake_force
			f = move_toward(f, -reverse_speed * -_throttle, rate * delta)
		else:
			f = move_toward(f, 0.0, coast_drag * delta)
		if _handbrake:
			f = move_toward(f, 0.0, brake_force * 0.5 * delta)
		var g := drift_grip if (_handbrake and driven) else grip
		lat = lerpf(lat, 0.0, 1.0 - exp(-g * delta))
	vy -= air_gravity * delta

	velocity = fwd * f + right * lat + Vector3.UP * vy
	var before := velocity
	_was_on_floor = on_floor
	move_and_slide()
	_after_slide(before)
	var new_fwd := velocity.dot(fwd)
	_long_accel = (new_fwd - _fwd_speed) / maxf(delta, 0.0001)
	_fwd_speed = new_fwd


func _after_slide(before: Vector3) -> void:
	# Springy "boing" off walls when hit hard.
	for i in get_slide_collision_count():
		var c := get_slide_collision(i)
		var n := c.get_normal()
		if absf(n.y) < 0.5:
			var impact := -before.dot(n)
			if impact > 7.0:
				var b := before.bounce(n) * wall_bounce
				b.y = maxf(b.y, 3.0)
				velocity = b
				_kick_squash(0.8)
				break
	var on_floor := is_on_floor()
	if on_floor and not _was_on_floor and _last_air_vy < -6.0:
		_kick_squash(clampf(-_last_air_vy / 18.0, 0.3, 1.2))
	if not on_floor:
		_last_air_vy = velocity.y


func _kick_squash(strength: float) -> void:
	_squash = clampf(_squash + strength * squash_amount, -0.35, 0.35)


# ---------------------------------------------------------------- visuals

func _process(delta: float) -> void:
	# Squash-and-stretch spring, sub-stepped so a slow frame (or an iPad hitch)
	# can never make it explode.
	var remaining := minf(delta, 0.25)
	while remaining > 0.0:
		var dt := minf(remaining, 1.0 / 120.0)
		_squash_vel += (-180.0 * _squash - 12.0 * _squash_vel) * dt
		_squash += _squash_vel * dt
		remaining -= dt
	_visual.scale = Vector3(1.0 + _squash * 0.5, 1.0 - _squash, 1.0 + _squash * 0.5)
	# Nose lifts when accelerating, dives when braking; body leans out of turns.
	var pitch := clampf(_long_accel * pitch_amount, -0.12, 0.12)
	var roll := clampf(_yaw_rate * absf(_fwd_speed) * roll_amount, -0.15, 0.15)
	var k := 1.0 - exp(-6.0 * delta)
	_visual.rotation.x = lerpf(_visual.rotation.x, pitch, k)
	_visual.rotation.z = lerpf(_visual.rotation.z, roll, k)
	# Wheels.
	for w in _wheel_spinners:
		w.rotate_x(-_fwd_speed / 0.42 * delta)
	for p in _front_pivots:
		p.rotation.y = lerpf(p.rotation.y, -_steer * 0.45, k)
	# Rear doors.
	for i in _door_pivots.size():
		var side := -1.0 if i == 0 else 1.0
		var target := deg_to_rad(100.0) * side if doors_open else 0.0
		_door_pivots[i].rotation.y = lerpf(_door_pivots[i].rotation.y, target, 1.0 - exp(-8.0 * delta))
	# Light bar.
	if siren_on:
		_siren_t += delta
		var phase := int(_siren_t * 5.0) % 2
		for i in 2:
			var lit := i == phase
			_siren_lights[i].visible = lit
			_siren_mats[i].emission_energy_multiplier = 4.0 if lit else 0.3
	else:
		for i in 2:
			_siren_lights[i].visible = false
			_siren_mats[i].emission_energy_multiplier = 0.0


# ---------------------------------------------------------------- build

func _mat(c: Color) -> StandardMaterial3D:
	var m := StandardMaterial3D.new()
	m.albedo_color = c
	m.roughness = 0.45
	return m


func _box(parent: Node3D, pos: Vector3, box_size: Vector3, c: Color) -> MeshInstance3D:
	var mi := MeshInstance3D.new()
	var bm := BoxMesh.new()
	bm.size = box_size
	mi.mesh = bm
	mi.position = pos
	mi.material_override = _mat(c)
	parent.add_child(mi)
	return mi


func _build() -> void:
	# Rounded (capsule) collision glides over kerbs and ramp edges.
	var shape := CapsuleShape3D.new()
	shape.radius = 1.05
	shape.height = 5.4
	var cs := CollisionShape3D.new()
	cs.shape = shape
	cs.rotation.x = PI * 0.5
	cs.position.y = 1.05
	add_child(cs)

	_visual = Node3D.new()
	add_child(_visual)
	var white := Color(0.97, 0.97, 0.97)
	var red := Color(0.9, 0.12, 0.12)
	var dark := Color(0.12, 0.12, 0.13)
	_box(_visual, Vector3(0, 0.98, 0), Vector3(2.2, 0.85, 5.4), white)            # chassis
	_box(_visual, Vector3(0, 2.1, 1.0), Vector3(2.3, 1.4, 3.4), white)            # patient box
	_box(_visual, Vector3(0, 1.85, -1.75), Vector3(2.1, 0.9, 1.9), white)         # cab
	_box(_visual, Vector3(0, 1.95, -2.72), Vector3(1.9, 0.6, 0.06), Color(0.2, 0.35, 0.55))  # windshield
	_box(_visual, Vector3(0, 1.25, 0), Vector3(2.32, 0.22, 5.42), red)            # stripe
	_box(_visual, Vector3(0, 0.68, -2.75), Vector3(2.25, 0.3, 0.16), dark)        # bumpers
	_box(_visual, Vector3(0, 0.68, 2.75), Vector3(2.25, 0.3, 0.16), dark)
	for sx in [-1.0, 1.0]:
		_box(_visual, Vector3(1.16 * sx, 2.2, 1.0), Vector3(0.04, 0.95, 0.3), red)  # red crosses
		_box(_visual, Vector3(1.16 * sx, 2.2, 1.0), Vector3(0.04, 0.3, 0.95), red)

	# Wheels: pivot (steers) > spinner (rolls) > tyre + hub bar.
	for wz in [-1.8, 1.8]:
		for wx in [-1.02, 1.02]:
			var pivot := Node3D.new()
			pivot.position = Vector3(wx, 0.42, wz)
			_visual.add_child(pivot)
			var spinner := Node3D.new()
			pivot.add_child(spinner)
			var tyre := MeshInstance3D.new()
			var cyl := CylinderMesh.new()
			cyl.top_radius = 0.42
			cyl.bottom_radius = 0.42
			cyl.height = 0.32
			tyre.mesh = cyl
			tyre.rotation.z = PI * 0.5
			tyre.material_override = _mat(dark)
			spinner.add_child(tyre)
			_box(spinner, Vector3.ZERO, Vector3(0.34, 0.5, 0.12), Color(0.8, 0.8, 0.85))
			_wheel_spinners.append(spinner)
			if wz < 0.0:
				_front_pivots.append(pivot)

	# Light bar: red left, blue right, each with a real light.
	_box(_visual, Vector3(0, 2.36, -1.6), Vector3(1.6, 0.12, 0.4), dark)
	for i in 2:
		var col := Color(1.0, 0.1, 0.1) if i == 0 else Color(0.15, 0.35, 1.0)
		var m := StandardMaterial3D.new()
		m.albedo_color = col
		m.emission_enabled = true
		m.emission = col
		m.emission_energy_multiplier = 0.0
		var lamp := _box(_visual, Vector3(-0.45 if i == 0 else 0.45, 2.5, -1.6), Vector3(0.6, 0.22, 0.35), col)
		lamp.material_override = m
		_siren_mats.append(m)
		var light := OmniLight3D.new()
		light.light_color = col
		light.omni_range = 9.0
		light.light_energy = 3.0
		light.visible = false
		light.position = lamp.position + Vector3.UP * 0.3
		_visual.add_child(light)
		_siren_lights.append(light)

	# Rear doors hinge on the outer edges and swing open toward the back.
	for sx in [-1.0, 1.0]:
		var pivot := Node3D.new()
		pivot.position = Vector3(1.15 * sx, 2.1, 2.72)
		_visual.add_child(pivot)
		_box(pivot, Vector3(-0.575 * sx, 0, 0.03), Vector3(1.12, 1.3, 0.06), white)
		_box(pivot, Vector3(-0.575 * sx, 0.25, 0.07), Vector3(0.6, 0.4, 0.02), Color(0.2, 0.35, 0.55))
		_door_pivots.append(pivot)

	# Where the stretcher rides when loaded (hidden inside the body).
	stow_point = Node3D.new()
	stow_point.name = "StowPoint"
	stow_point.position = Vector3(0, 0.75, 0.9)
	add_child(stow_point)
