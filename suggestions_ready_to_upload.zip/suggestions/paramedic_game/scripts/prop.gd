extends RigidBody3D
## A physics prop: medical bags, belongings and the patient.
## Bags can be picked up and tossed. Anything that touches the stretcher's
## sticky pad (except the patient, who is transferred on purpose) sticks to it.

const LAYER_PROPS := 1 << 4
const MASK_PROPS := (1 << 0) | (1 << 1) | (1 << 3) | (1 << 4)  # world, vehicle, stretcher, props

@export var kind: String = "bag"          # "bag" or "patient"
@export var label: String = "Trauma bag"
@export var prop_mass: float = 6.0
@export var size: Vector3 = Vector3(0.7, 0.38, 0.45)
@export var color: Color = Color(0.86, 0.16, 0.16)

var is_stuck: bool = false
var is_held: bool = false


func _ready() -> void:
	mass = prop_mass
	collision_layer = LAYER_PROPS
	collision_mask = MASK_PROPS
	continuous_cd = true
	freeze_mode = RigidBody3D.FREEZE_MODE_KINEMATIC
	linear_damp_mode = RigidBody3D.DAMP_MODE_REPLACE
	linear_damp = 0.0  # keeps auto-aimed tosses on their predicted arc
	add_to_group("props")
	add_to_group(kind)
	if kind == "patient":
		_build_patient()
	else:
		_build_bag()


## Distance from the prop's origin down to the surface it rests on.
func rest_height() -> float:
	if kind == "patient":
		return 0.25
	return size.y * 0.5


## Half extents of the prop on the pad (x = width, y = length).
func footprint() -> Vector2:
	if kind == "patient":
		return Vector2(0.3, 0.9)
	return Vector2(size.x, size.z) * 0.5


func set_physics_enabled(on: bool) -> void:
	freeze = not on
	collision_layer = LAYER_PROPS if on else 0
	collision_mask = MASK_PROPS if on else 0
	if on:
		sleeping = false


func _mat(c: Color) -> StandardMaterial3D:
	var m := StandardMaterial3D.new()
	m.albedo_color = c
	m.roughness = 0.8
	return m


func _box(pos: Vector3, box_size: Vector3, c: Color) -> void:
	var mi := MeshInstance3D.new()
	var bm := BoxMesh.new()
	bm.size = box_size
	mi.mesh = bm
	mi.position = pos
	mi.material_override = _mat(c)
	add_child(mi)


func _build_bag() -> void:
	_box(Vector3.ZERO, size, color)
	_box(Vector3.ZERO, Vector3(size.x * 1.01, size.y * 0.22, size.z * 1.01), Color(1, 1, 1))
	_box(Vector3(0, size.y * 0.5 + 0.03, 0), Vector3(size.x * 0.5, 0.06, 0.06), color.darkened(0.5))
	var cs := CollisionShape3D.new()
	var shape := BoxShape3D.new()
	shape.size = size
	cs.shape = shape
	add_child(cs)


func _build_patient() -> void:
	# Lies along local Z, head toward +Z (the stretcher's handle end).
	var body := MeshInstance3D.new()
	var cap := CapsuleMesh.new()
	cap.radius = 0.25
	cap.height = 1.75
	body.mesh = cap
	body.rotation = Vector3(PI * 0.5, 0, 0)
	body.material_override = _mat(color)
	add_child(body)
	var head := MeshInstance3D.new()
	var sph := SphereMesh.new()
	sph.radius = 0.17
	sph.height = 0.34
	head.mesh = sph
	head.position = Vector3(0, 0.12, 0.72)
	head.material_override = _mat(Color(0.95, 0.78, 0.62))
	add_child(head)
	_box(Vector3(0, 0.2, -0.25), Vector3(0.56, 0.12, 1.1), Color(0.55, 0.75, 0.95))  # blanket
	var cs := CollisionShape3D.new()
	var shape := CapsuleShape3D.new()
	shape.radius = 0.25
	shape.height = 1.75
	cs.shape = shape
	cs.rotation = Vector3(PI * 0.5, 0, 0)
	add_child(cs)
