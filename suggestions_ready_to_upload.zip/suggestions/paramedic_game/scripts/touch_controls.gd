extends Control
## Multi-touch controls for iPad / iPhone (Xogot): a floating joystick on the
## left, action buttons on the bottom right, and drag-to-orbit on the rest of
## the right half. Buttons press the same input actions as keyboard/gamepad.

signal camera_drag(dx: float)

@export var force_show: bool = false
@export var joystick_radius: float = 90.0
@export var button_radius: float = 46.0

var _buttons: Array = [
	{"action": "interact", "label": "USE", "col": 0, "row": 0},
	{"action": "grab", "label": "GRAB", "col": 1, "row": 0},
	{"action": "throw", "label": "TOSS", "col": 2, "row": 0},
	{"action": "brake", "label": "BRAKE", "col": 3, "row": 0},
	{"action": "siren", "label": "SIREN", "col": 0, "row": 1},
	{"action": "raise", "label": "RAISE", "col": 1, "row": 1},
	{"action": "lower", "label": "LOWER", "col": 2, "row": 1},
	{"action": "release_pad", "label": "UNSTICK", "col": 3, "row": 1},
]
var _touch_actions: Dictionary = {}  # touch index -> action name
var _joy_index: int = -1
var _joy_center: Vector2 = Vector2.ZERO
var _joy_knob: Vector2 = Vector2.ZERO
var _cam_index: int = -1


func _ready() -> void:
	set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	mouse_filter = Control.MOUSE_FILTER_IGNORE
	visible = force_show or DisplayServer.is_touchscreen_available()
	resized.connect(queue_redraw)


func _input(event: InputEvent) -> void:
	if not visible:
		return
	if event is InputEventScreenTouch:
		var st := event as InputEventScreenTouch
		if st.pressed:
			_press(st.index, st.position)
		else:
			_release(st.index)
	elif event is InputEventScreenDrag:
		var sd := event as InputEventScreenDrag
		_drag(sd.index, sd.position, sd.relative)


func _press(index: int, pos: Vector2) -> void:
	for b in _buttons:
		if pos.distance_to(_button_center(b)) <= button_radius * 1.2:
			var action: String = b["action"]
			_touch_actions[index] = action
			Input.action_press(action)
			queue_redraw()
			return
	if pos.x < size.x * 0.45:
		if _joy_index == -1:
			_joy_index = index
			_joy_center = pos
			_joy_knob = pos
			queue_redraw()
	elif _cam_index == -1:
		_cam_index = index


func _release(index: int) -> void:
	if index == _joy_index:
		_joy_index = -1
		for a in ["move_left", "move_right", "move_up", "move_down"]:
			Input.action_release(a)
		queue_redraw()
	elif _touch_actions.has(index):
		var action: String = _touch_actions[index]
		_touch_actions.erase(index)
		if not _touch_actions.values().has(action):
			Input.action_release(action)
		queue_redraw()
	elif index == _cam_index:
		_cam_index = -1


func _drag(index: int, pos: Vector2, rel: Vector2) -> void:
	if index == _joy_index:
		_joy_knob = _joy_center + (pos - _joy_center).limit_length(joystick_radius)
		var v := (_joy_knob - _joy_center) / joystick_radius
		_set_axis("move_left", "move_right", v.x)
		_set_axis("move_up", "move_down", v.y)
		queue_redraw()
	elif index == _cam_index:
		camera_drag.emit(rel.x)


func _set_axis(negative: String, positive: String, value: float) -> void:
	if value < 0.0:
		Input.action_press(negative, -value)
		Input.action_release(positive)
	elif value > 0.0:
		Input.action_press(positive, value)
		Input.action_release(negative)
	else:
		Input.action_release(negative)
		Input.action_release(positive)


func _button_center(b: Dictionary) -> Vector2:
	var col: int = b["col"]
	var row: int = b["row"]
	var spacing := button_radius * 2.4
	return Vector2(size.x - button_radius * 1.6 - col * spacing, size.y - button_radius * 1.6 - row * spacing)


func _joy_rest() -> Vector2:
	return Vector2(joystick_radius * 1.6, size.y - joystick_radius * 1.6)


func _draw() -> void:
	var font := ThemeDB.fallback_font
	var center := _joy_center if _joy_index != -1 else _joy_rest()
	var knob := _joy_knob if _joy_index != -1 else center
	draw_circle(center, joystick_radius, Color(1, 1, 1, 0.12))
	draw_arc(center, joystick_radius, 0.0, TAU, 48, Color(1, 1, 1, 0.45), 3.0)
	draw_circle(knob, joystick_radius * 0.42, Color(1, 1, 1, 0.45))
	var pressed: Array = _touch_actions.values()
	for b in _buttons:
		var c := _button_center(b)
		var is_down: bool = pressed.has(b["action"])
		draw_circle(c, button_radius, Color(0.9, 0.15, 0.15, 0.75) if is_down else Color(0.1, 0.1, 0.12, 0.5))
		draw_arc(c, button_radius, 0.0, TAU, 40, Color(1, 1, 1, 0.7), 2.5)
		var label: String = b["label"]
		var fs := 15
		draw_string(font, Vector2(c.x - button_radius, c.y + fs * 0.35), label,
				HORIZONTAL_ALIGNMENT_CENTER, button_radius * 2.0, fs, Color.WHITE)
