extends Camera3D
## Smooth third-person follow camera with presets for walking, pushing and
## driving. Orbit with J/L, the right stick, or by dragging on the right half
## of the touch screen. Pulls in when a building would block the view.

@export var orbit_speed: float = 2.2
@export var touch_orbit_sensitivity: float = 0.008
@export var manual_hold_time: float = 1.6

var target: Node3D
var yaw: float = 0.0
var preset: String = "walk"

var _distance: float = 6.0
var _height: float = 3.2
var _look_height: float = 1.2
var _follow_rate: float = 1.0
var _cur_distance: float = 6.0
var _cur_height: float = 3.2
var _manual_timer: float = 0.0


func _ready() -> void:
	fov = 70.0
	far = 400.0


func set_target(t: Node3D, new_preset: String) -> void:
	target = t
	preset = new_preset
	match preset:
		"drive":
			_distance = 10.5
			_height = 4.6
			_look_height = 1.6
			_follow_rate = 3.0
		"push":
			_distance = 6.8
			_height = 3.6
			_look_height = 0.9
			_follow_rate = 2.5
		_:
			_distance = 6.0
			_height = 3.2
			_look_height = 1.2
			_follow_rate = 1.0


## Touch drag from touch_controls.gd.
func orbit(dx: float) -> void:
	yaw -= dx * touch_orbit_sensitivity
	_manual_timer = manual_hold_time


func snap() -> void:
	if target == null:
		return
	_cur_distance = _distance
	_cur_height = _height
	global_position = _goal()
	look_at(target.global_position + Vector3.UP * _look_height, Vector3.UP)


func _physics_process(delta: float) -> void:
	if target == null or not is_instance_valid(target):
		return
	var orbit_input := Input.get_axis("cam_left", "cam_right")
	if absf(orbit_input) > 0.1:
		yaw -= orbit_input * orbit_speed * delta
		_manual_timer = manual_hold_time
	if _manual_timer > 0.0:
		_manual_timer -= delta
	else:
		var rate := _follow_rate
		if preset == "walk":
			# On foot, only swing behind you while you walk away from the camera.
			var v = target.get("velocity")
			var moving: bool = v is Vector3 and Vector2(v.x, v.z).length() > 1.0
			var cam_fwd := Vector3(-sin(yaw), 0.0, -cos(yaw))
			var facing := -target.global_basis.z
			rate = _follow_rate if moving and cam_fwd.dot(facing) > 0.3 else 0.0
		yaw = lerp_angle(yaw, target.global_rotation.y, 1.0 - exp(-rate * delta))
	_cur_distance = lerpf(_cur_distance, _distance, 1.0 - exp(-3.0 * delta))
	_cur_height = lerpf(_cur_height, _height, 1.0 - exp(-3.0 * delta))

	var look := target.global_position + Vector3.UP * _look_height
	var goal := _goal()
	var smooth := 10.0
	var query := PhysicsRayQueryParameters3D.create(look, goal, 1)  # world layer only
	var hit := get_world_3d().direct_space_state.intersect_ray(query)
	if not hit.is_empty():
		goal = hit["position"] + hit["normal"] * 0.3
		smooth = 25.0
	global_position = global_position.lerp(goal, 1.0 - exp(-smooth * delta))
	if global_position.distance_to(look) > 0.1:
		look_at(look, Vector3.UP)


func _goal() -> Vector3:
	return target.global_position + Vector3(sin(yaw), 0.0, cos(yaw)) * _cur_distance + Vector3.UP * _cur_height
