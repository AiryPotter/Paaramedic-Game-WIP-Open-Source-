extends Area3D
## The stretcher's big sticky pad. A tossed or dropped bag that touches it
## sticks where it lands (frozen and parented to the pad, stacking on top of
## whatever is already there). The patient is placed here on purpose by the
## transfer action. Everything stays put until released.

signal prop_stuck(prop: Node3D)
signal prop_released(prop: Node3D)

@export var pad_size: Vector3 = Vector3(1.2, 0.05, 2.3)
@export var catch_height: float = 0.55     # how far above the pad it grabs things
@export var restick_cooldown: float = 1.0  # after UNSTICK, ignore contacts briefly
@export var release_speed: float = 2.5

var stuck: Array = []
var _cooldown: float = 0.0


func _ready() -> void:
	collision_layer = 0
	collision_mask = 1 << 4  # props
	monitoring = true
	monitorable = false
	var cs := CollisionShape3D.new()
	var box := BoxShape3D.new()
	box.size = Vector3(pad_size.x, catch_height, pad_size.z)
	cs.shape = box
	cs.position = Vector3(0, pad_size.y + catch_height * 0.5, 0)
	add_child(cs)
	var mi := MeshInstance3D.new()
	var bm := BoxMesh.new()
	bm.size = pad_size
	mi.mesh = bm
	mi.position = Vector3(0, pad_size.y * 0.5, 0)
	var m := StandardMaterial3D.new()
	m.albedo_color = Color(0.62, 0.9, 0.18)
	m.roughness = 0.2  # glossy = "sticky"
	mi.material_override = m
	add_child(mi)
	body_entered.connect(_on_body_entered)


func _physics_process(delta: float) -> void:
	if _cooldown > 0.0:
		_cooldown -= delta


func _on_body_entered(body) -> void:
	if _cooldown > 0.0:
		return
	if not body.is_in_group("bag"):
		return  # the patient is only placed via the transfer action
	if body.is_stuck or body.is_held:
		return
	stick.call_deferred(body)


## Stick a prop to the pad. Safe to call from gameplay code (use call_deferred
## when inside a physics callback).
func stick(prop) -> void:
	if not is_instance_valid(prop) or stuck.has(prop) or prop.is_held:
		return
	prop.is_stuck = true
	prop.set_physics_enabled(false)
	prop.linear_velocity = Vector3.ZERO
	prop.angular_velocity = Vector3.ZERO
	prop.reparent(self, true)
	if prop.kind == "patient":
		prop.rotation = Vector3.ZERO
	else:
		prop.rotation = Vector3(0.0, prop.rotation.y, 0.0)
	stuck.append(prop)
	_relayout()
	prop_stuck.emit(prop)


## Remove a prop from the pad without turning physics back on (picked up by hand).
func detach(prop) -> void:
	if not stuck.has(prop):
		return
	stuck.erase(prop)
	prop.is_stuck = false
	_relayout()


## UNSTICK: drop everything off the side of the stretcher.
func release_all(world: Node, side: Vector3) -> int:
	var count := stuck.size()
	for prop in stuck.duplicate():
		stuck.erase(prop)
		prop.reparent(world, true)
		prop.is_stuck = false
		prop.set_physics_enabled(true)
		prop.linear_velocity = side.normalized() * release_speed + Vector3.UP * 1.5
		prop_released.emit(prop)
	_cooldown = restick_cooldown
	return count


## Used at the hospital: hand over the patient and the bags with them.
func clear_and_free() -> void:
	for prop in stuck:
		if is_instance_valid(prop):
			prop.queue_free()
	stuck.clear()


func total_mass() -> float:
	var m := 0.0
	for prop in stuck:
		if is_instance_valid(prop):
			m += prop.prop_mass
	return m


func has_patient() -> bool:
	return count_kind("patient") > 0


func count_kind(kind: String) -> int:
	var n := 0
	for prop in stuck:
		if is_instance_valid(prop) and prop.kind == kind:
			n += 1
	return n


## Patient lies in the middle; bags keep the spot where they landed and stack
## on top of anything already under them.
func _relayout() -> void:
	var placed: Array = []
	for prop in stuck:
		if prop.kind == "patient":
			_place(prop, placed)
			placed.append(prop)
	for prop in stuck:
		if prop.kind != "patient":
			_place(prop, placed)
			placed.append(prop)


func _place(prop, placed: Array) -> void:
	var fp: Vector2 = prop.footprint()
	var hx := maxf(pad_size.x * 0.5 - fp.x, 0.0)
	var hz := maxf(pad_size.z * 0.5 - fp.y, 0.0)
	var pos: Vector3 = prop.position
	if prop.kind == "patient":
		pos.x = 0.0
		pos.z = 0.0
	else:
		pos.x = clampf(pos.x, -hx, hx)
		pos.z = clampf(pos.z, -hz, hz)
	var base := pad_size.y
	for other in placed:
		var ofp: Vector2 = other.footprint()
		var opos: Vector3 = other.position
		if absf(opos.x - pos.x) < (fp.x + ofp.x) * 0.9 and absf(opos.z - pos.z) < (fp.y + ofp.y) * 0.9:
			var top: float = opos.y + other.rest_height()
			base = maxf(base, top)
	pos.y = base + prop.rest_height()
	prop.position = pos
