extends RefCounted
## Registers every input action in code, so project.godot stays tiny and the
## game behaves the same in Xogot (iPad keyboard, Bluetooth controller, touch)
## and in desktop Godot. Touch buttons press these same actions.

static func setup() -> void:
	_add("move_up", [KEY_W, KEY_UP], [], [[JOY_AXIS_LEFT_Y, -1.0]])
	_add("move_down", [KEY_S, KEY_DOWN], [], [[JOY_AXIS_LEFT_Y, 1.0]])
	_add("move_left", [KEY_A, KEY_LEFT], [], [[JOY_AXIS_LEFT_X, -1.0]])
	_add("move_right", [KEY_D, KEY_RIGHT], [], [[JOY_AXIS_LEFT_X, 1.0]])
	_add("cam_left", [KEY_J], [], [[JOY_AXIS_RIGHT_X, -1.0]])
	_add("cam_right", [KEY_L], [], [[JOY_AXIS_RIGHT_X, 1.0]])
	_add("interact", [KEY_E, KEY_ENTER], [JOY_BUTTON_A], [])
	_add("grab", [KEY_F], [JOY_BUTTON_X], [])
	_add("throw", [KEY_Q], [JOY_BUTTON_RIGHT_SHOULDER], [])
	_add("raise", [KEY_R], [JOY_BUTTON_DPAD_UP], [])
	_add("lower", [KEY_C], [JOY_BUTTON_DPAD_DOWN], [])
	_add("siren", [KEY_H], [JOY_BUTTON_Y], [])
	_add("release_pad", [KEY_G], [JOY_BUTTON_B], [])
	_add("brake", [KEY_SPACE], [JOY_BUTTON_LEFT_SHOULDER], [[JOY_AXIS_TRIGGER_LEFT, 1.0]])


static func _add(action: String, keys: Array, buttons: Array, axes: Array) -> void:
	if InputMap.has_action(action):
		return
	InputMap.add_action(action, 0.2)
	for k in keys:
		var ek := InputEventKey.new()
		ek.physical_keycode = k
		InputMap.action_add_event(action, ek)
	for b in buttons:
		var eb := InputEventJoypadButton.new()
		eb.button_index = b
		InputMap.action_add_event(action, eb)
	for a in axes:
		var em := InputEventJoypadMotion.new()
		em.axis = a[0]
		em.axis_value = a[1]
		InputMap.action_add_event(action, em)
