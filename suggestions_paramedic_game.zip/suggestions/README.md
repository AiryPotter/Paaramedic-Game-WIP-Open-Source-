🔒 CONFIDENTIAL — Owen's original work.

# Suggestions

Ideas, prototypes and recommendations that are **not** part of the main project yet.
Each subfolder is self-contained and can be opened, tried and deleted without touching anything else.

| Folder | What it is | Status |
|---|---|---|
| [`paramedic_game/`](paramedic_game/) | Paramedic game prototype for **Xogot** (Godot on iPad/iPhone): arcade ambulance, big sim stretcher with a sticky pad, toss-able bags, patient transfer, ER hand-over. GDScript only. | Playable prototype, smoke-tested in Godot 4.4.1 |

Start with `paramedic_game/README.md`, then `paramedic_game/RECOMMENDATIONS.md`.
