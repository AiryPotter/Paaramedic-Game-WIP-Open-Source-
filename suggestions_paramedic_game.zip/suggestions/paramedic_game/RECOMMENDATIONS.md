🔒 CONFIDENTIAL — Owen's original work.

# Recommendations — Paramedic Rush

## 1. Design decisions in this prototype

| Decision | Why |
|---|---|
| Ambulance uses a hand-rolled `CharacterBody3D` model, **not** `VehicleBody3D` | You asked for cartoony, arcade driving. `VehicleBody3D` is suspension and tyre physics, harder to make "fun-first" and twitchier on mobile. The hand-rolled model gives exact control: grip, drift, air control, bounce. |
| Stretcher is **sim**, ambulance is **arcade** | The contrast is the game: fast, silly driving, then careful, weighty stretcher work. |
| Stretcher is oversized (1.25 × 2.35 m; a real one is about 0.6 × 2.0 m) | So tossed bags land easily, as you asked. Change `deck_size` in `stretcher.gd`. |
| Sticky pad freezes props and parents them to the pad | Rock-solid on mobile: no physics jitter while pushing or driving, and it costs nothing per frame. |
| Toss auto-aim solves a ballistic arc onto the pad | Throwing precisely with a touch joystick is frustrating. Auto-aim only kicks in when the stretcher is within 9 m and 60° of where you face. |
| Push power limit (F = P / v) plus rolling resistance | This is what makes a 120 kg patient crawl up the ER ramp (about 1.4 m/s) while an empty stretcher rolls easily. |
| Everything built in code, input map in code | No `.import` files or editor-only setup, so it is safe to move between Xogot and desktop. |

## 2. Tuning knobs (start here)

| Feel | File and variable | Default | Try |
|---|---|---|---|
| Ambulance top speed | `ambulance.gd` `max_speed` | 24 m/s | 18 for a small town |
| Ambulance punch | `acceleration` | 11 | 8 for heavier, 14 for zippy |
| Drift amount | `drift_grip` (lower slides more) | 1.4 | 0.8 to 2.5 |
| Normal grip | `grip` | 7 | 5 for a looser cartoon feel |
| Jump floatiness | `air_gravity` | 24 | 18 for floaty, 30 for snappy |
| Bounciness | `wall_bounce`, `squash_amount` | 0.45, 0.2 | up to 0.7, 0.3 |
| Stretcher weight | `stretcher.gd` `base_mass` | 45 kg | |
| How hard you can push uphill | `push_power` | 320 W | 250 makes ramps a real challenge |
| Stretcher turning | `turn_rate` | 1.8 | 1.2 for heavier |
| Lift speed | `lift_speed` | 0.8 m/s | |
| Pad grab height | `sticky_pad.gd` `catch_height` | 0.55 m | 0.8 is more forgiving |
| Toss assist | `paramedic.gd` `auto_aim_range`, `auto_aim_angle` | 9 m, 60° | 0° turns assist off |
| Scoring | `main.gd` exports | 500 / 4 per s / 100 per bag | |

## 3. Using REA for reference (option 4A), kept outside Xogot

REA runs on a **desktop** with decompilers. Nothing from REA goes into this project except **numbers and notes**. The project stays pure GDScript, so it keeps working in Xogot.

1. **Pick a game you own** with driving or stretcher feel you like. Use it lawfully: for study and interoperability, not copying code or assets. Avoid anything online or protected by anti-cheat or DRM.
2. **Ask REA questions that produce numbers, not code.** For example:
   - "What is the vehicle's max speed, acceleration and braking?"
   - "How is lateral grip reduced during a handbrake?"
   - "What gravity multiplier applies while airborne?"
   - "How does push speed change with load mass or slope?"
3. **Record each finding** as seen, inferred or unknown (REA's own evidence labels).
4. **Map the numbers onto the tuning table above.** Each REA finding should change one `@export` value, never paste in code.
5. **Keep a short note per change** in this file, for example: "drift_grip 1.4 → 1.1 (inferred from game X handbrake behaviour)". That gives you a traceable record that the game is original.

## 4. Next steps (suggested order)

1. **Test on iPad in Xogot.** Check frame rate (target 60 fps), button size and joystick feel. If buttons feel small, raise `button_radius` in `touch_controls.gd`.
2. **Audio.** Siren loop, engine pitch tied to speed, a "boing" on bounces, and a sticky "thwap" when bags land. Use CC0 sounds, for example Kenney audio packs.
3. **Art swap.** Replace the primitive ambulance with a CC0 model. Kenney's Car Kit is CC0, but the page doesn't list its models, so check the preview for an ambulance. Keep the same node names so the scripts still work.
4. **Patient care minigame** at the scene before transfer: check breathing, apply oxygen, using the bags you collected. This is what makes collecting bags matter beyond points.
5. **Traffic and pedestrians** that pull over when the siren is on.
6. **Map and minimap**, plus more hospitals.
7. **Save high scores**, using `user://` (works in Xogot).
8. **Physics interpolation** (Project Settings) if the camera looks steppy on 120 Hz iPads.

## 5. Open-source sources considered

| Source | License | What the license allows | Used? |
|---|---|---|---|
| [Godot Engine](https://godotengine.org) (Xogot uses Godot's open-source runtime) | MIT | Commercial use; keep the copyright notice; no share-alike | Yes: engine and runtime |
| [Godot Truck Town demo](https://godotengine.org/asset-library/asset/2752) | MIT | Commercial use with notice | Reference only. Considered and rejected for arcade feel; no code copied |
| [Kenney Car Kit](https://www.kenney.nl/assets/car-kit) | CC0 | Public domain: commercial use, no attribution required | Suggested for the art swap (step 3) |

No restrictive licenses (GPL, CC-BY-NC, no-derivatives) are involved.
